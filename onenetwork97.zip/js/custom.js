$(document).ready(function() {
$("#enq_submit").click(function(){
	
	fname = $("#fname").val();
	email = $("#email").val();
	enquiry2 = $("#enquiry").val();
	enquiry = encodeURIComponent(enquiry2);
	intRegex = /[0-9 -()+]+$/;
	regEmail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{1,4})$/;
	
	if(fname == ''){
		alert('Please enter your first name.');
		$("#fname").focus();
		return false;
		}
	else if(email == ''){
		alert('Please enter your email id.');
		$("#email").focus();
		return false;
		}	
	else if(regEmail.test(email) == false){
		alert('Invalid email address!');
		document.getElementById("email").focus();
		return false;
		}
	else if(enquiry2 == ''){
		alert('Please write your enquiry.');
		$("#enquiry").focus();
		return false;
		}
	else{
		
		$.ajax({
				url: 'ajxContact.php?fname='+fname+'&email='+email+'&enquiry='+enquiry,
							
				success: function(rohit){
					if(rohit == 'error'){
						$("#conterror").css("display", "block");
						$("#contsuccess").css("display", "none");
					}
					else {
						$("#contsuccess").css("display", "block");
						$("#conterror").css("display", "none");	
						$("#fname").val('');
						$("#email").val('');
						$("#enquiry").val('');
						}
					}
			});	
								
	}		
	
})




$("#career_submit").click(function(){
	
	fname = $("#fname").val();
	lname = $("#lname").val();
	email = $("#email").val();
	phone = $("#phone").val();
	opening = $("#opening").val();
	upload = $("#upload").val();
	enquiry2 = $("#enquiry").val();
	enquiry = encodeURIComponent(enquiry2);
	intRegex = /[0-9 -()+]+$/;
	regEmail = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{1,4})$/;
	
	if(fname == ''){
		alert('Please enter your first name.');
		$("#fname").focus();
		return false;
		}
	else if(lname == ''){
		alert('Please enter your last name.');
		$("#lname").focus();
		return false;
		}
	else if(phone == ''){
		alert('Please enter contact number.');
		$("#phone").focus();
		return false;
		}
	else if((phone.length < 5) || (!intRegex.test(phone))){
		alert('Invalid contact number!');
		$("#phone").focus();
		return false;
		}
	else if(email == ''){
		alert('Please enter your email id.');
		$("#email").focus();
		return false;
		}	
	else if(regEmail.test(email) == false){
		alert('Invalid email address!');
		document.getElementById("email").focus();
		return false;
		}
	else if(opening == ''){
		alert('Please choose your area.');
		$("#opening").focus();
		return false;
		}
	else if(upload == ''){
		alert('Please upload your resume.');
		$("#upload").focus();
		return false;
		}
	else if(enquiry == ''){
		alert('Please write your enquiry.');
		$("#enquiry").focus();
		return false;
		}
	else{
		document.frmQuery.submit();								
	}		
	
})
})
