<?php
date_default_timezone_set('Asia/Calcutta');
if(isset($_GET['email'])){
		$fname = $_GET['fname'];
		$email = $_GET['email'];
		$ur_msg = str_replace("\n", "<br />", $_GET['enquiry']);
		$date_time=date("F j, Y, g:i a");

		//$to = '';
		$to = 'eesha118@gmail.com';
		$subject = "Enquiry Details to Eesha from $fname";
		$message= "<table border='0' cellpadding='4' cellspacing='4' width='100%'>
              <tr>
                <td align='left' width='35%'>&nbsp;</td>
                <td align='left' width='60%'>&nbsp;</td>
              </tr>
			  <tr>
              <td style='font-size:1.3em;' colspan='2'>Enquiry Details - JB Khokani</td>
            </tr>
			<tr>
                <td align='left' width='35%'>&nbsp;</td>
                <td align='left' width='60%'>&nbsp;</td>
              </tr>
              <tr>
                <td align='left' width='35%'><strong>Person's Name :</strong></td>
                <td align='left' width='60%'>
                ".$_GET['fname']."</td>
              </tr>    
			  <tr>
                <td align='left' width='35%'><strong>Email :</strong></td>
                <td align='left' width='60%'>
                ".$_GET["email"]."</td>
              </tr> 
			  <tr>
                <td align='left' width='35%' valign='top'><strong>Message :</strong></td>
                <td align='left' width='60%'>
                $ur_msg</td>
              </tr> 
			  <tr>
                <td align='left' width='35%'><strong>Date/Time of Enquiry (IST):</strong></td>
                <td align='left' width='60%'>
                $date_time</td>
              </tr>        
            </table>";
			
	$headers  = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$headers .= 'From:' .$email. "\r\n";
	$headers .= 'Bcc: eesha118@gmail.com' . "\r\n";				
	
	mail($to, $subject, $message, $headers);

	echo'success';	
}
else
{
	echo'error';
}
?>