<?php
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ) {



	$statusMessages = array();

	define('FROM_EMAIL', 'info@onenetwork.co.in');

	define('FROM_EMAIL_NAME', 'One Network');

	define('TO_EMAIL', 'eesha118@gmail.com');

	define('REPLY_TO_EMAIL', 'noreply@onenetwork.co.in');



	if(isset($_POST) && !empty($_POST)) {

		$name = $_POST['author'];

		$email = $_POST['email'];

		$subject = $_POST['subject'];

		$comment = $_POST['comment'];

		$htmlMessage = "Hello, <br><br> Please see following registration details. <br><br>";

		$htmlMessage .= "Name: ". $name."<br>";

		$htmlMessage .= "Email: ". $email."<br>";

		$htmlMessage .= "Message: ". $comment."<br><br>";

		$htmlMessage .= "Regards, <br>";

		$htmlMessage .= "One Network";

		$header = "From: ".FROM_EMAIL_NAME." <".FROM_EMAIL.">\r\n";

		$header .= "Reply-To: ".REPLY_TO_EMAIL."\r\n";

		$header .= "MIME-Version: 1.0\r\n";

		$header .= "Content-type:text/html; charset=iso-8859-1\r\n";

		$header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";

		if (mail(TO_EMAIL, 'One Network: '.$subject, $htmlMessage, $header)) {

			echo 'success';

		} else {

			echo 'error';

		}

	}

} 

else {

	die("Unable to process this request");	

}